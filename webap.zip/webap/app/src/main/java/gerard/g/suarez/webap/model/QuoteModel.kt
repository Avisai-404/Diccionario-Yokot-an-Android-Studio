package gerard.g.suarez.webap.model

data class QuoteModel(val quote:String, val Author:String)
